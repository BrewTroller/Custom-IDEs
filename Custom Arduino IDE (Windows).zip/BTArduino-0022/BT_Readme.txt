BTArduino-0022.ZIP BT Modifications
-----------------------------------

* Official Arduin0-0022 Windows Package

* Sanguino 1284P Files
  - hardware\arduino\boards.txt
  - hardware\arduino\cores\arduino\cores\sanguino\*.*
  - hardware\arduino\bootloaders\atmega\ATmegaBOOT_168_atmega1284p.hex
  - hardware\arduino\bootloaders\atmega644p\*
  - hardware\tools\avr\bin\avrdude.exe
  - hardware\tools\avr\etc\avrdude.conf

* BT Libraries
  - libraries\DS2482_BT
  - libraries\encoder
  - libraries\FastPin
  - libraries\LiquidCrystalFP
  - libraries\Menu
  - libraries\OneWire
  - libraries\PID_Beta6

Fix arduino to work with latest (not needed for BT)
  - hardware\arduino\cores\arduino\cores\arduino\HardwareSerial.*
  - tools\avr\avr\include\avr\iomxx0_1.h